"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";

interface SearchArticle {
  category: string;
  title: string;
  slug: string;
  shortdescription?: string;
  date?: string;
  image?: string;
}

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [currentDate, setCurrentDate] = useState("");
  const [allArticles, setAllArticles] = useState<SearchArticle[]>([]);
  const pathname = usePathname();

  useEffect(() => {
    const now = new Date();
    const options: Intl.DateTimeFormatOptions = {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    };
    setCurrentDate(now.toLocaleDateString("en-US", options));
  }, []);

  // Fetch articles for live search indexing when search panel opens
  useEffect(() => {
    if (isSearchOpen && allArticles.length === 0) {
      const categories = ["world", "business", "us", "technology", "entertainment"];
      Promise.all(
        categories.map((cat) =>
          fetch(`/data/${cat}.json`)
            .then((res) => (res.ok ? res.json() : []))
            .catch(() => [])
        )
      ).then((results) => {
        const merged = results.flat() as SearchArticle[];
        setAllArticles(merged);
      });
    }
  }, [isSearchOpen, allArticles.length]);

  const categories = [
    { name: "HOME", href: "/" },
    { name: "WORLD", href: "/world" },
    { name: "U.S.", href: "/us" },
    { name: "BUSINESS", href: "/business" },
    { name: "TECHNOLOGY", href: "/technology" },
    { name: "ENTERTAINMENT", href: "/entertainment" },
    { name: "OPINION", href: "/us" },
    { name: "CULTURE", href: "/entertainment" },
  ];

  const searchResults = searchQuery.trim() === ""
    ? []
    : allArticles.filter(
        (art) =>
          art.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          art.category?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          art.shortdescription?.toLowerCase().includes(searchQuery.toLowerCase())
      );

  return (
    <header className="w-full bg-paper text-ink relative">
      {/* ------------------------------------------------------------- */}
      {/* SECTION 1: Elegant Utility Top Bar */}
      {/* ------------------------------------------------------------- */}
      <div className="border-b border-divider/30 py-2.5 px-4 md:px-8 text-xs font-medium bg-paper/80 backdrop-blur-xs">
        <div className="container mx-auto flex items-center justify-between gap-4">
          
          {/* Left: Date & Live Status Indicator */}
          <div className="flex items-center gap-2.5">
            <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse"></span>
            <span className="font-semibold tracking-tight text-ink font-sans">
              {currentDate || "Monday, August 10, 2026"}
            </span>
          </div>

          {/* Right: Weather Pill & Search Button */}
          <div className="flex items-center gap-3">
            {/* Weather Glass Pill */}
            <div className="hidden sm:flex items-center gap-1.5 text-gray-800 font-semibold text-xs font-sans bg-black/5 hover:bg-black/10 px-3 py-1 rounded-full transition-colors cursor-default">
              <svg className="w-4 h-4 text-amber-500" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zm1.414 8.486l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 1.414zM4 11a1 1 0 100-2H3a1 1 0 100 2h1z" clipRule="evenodd" />
              </svg>
              <span>New York 74°F</span>
            </div>

            {/* Quick Search Action Button */}
            <div className="relative">
              <button
                onClick={() => setIsSearchOpen(!isSearchOpen)}
                className={`flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-bold font-sans transition-all duration-300 shadow-xs cursor-pointer ${
                  isSearchOpen
                    ? "bg-red-700 text-white"
                    : "bg-ink text-paper hover:bg-amber-950"
                }`}
                aria-label="Toggle Search"
              >
                {isSearchOpen ? (
                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                ) : (
                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                )}
                <span>{isSearchOpen ? "Close" : "Search"}</span>
              </button>

              {/* Search Dropdown Panel */}
              {isSearchOpen && (
                <div className="absolute right-0 top-10 z-50 w-72 sm:w-96 md:w-[440px] bg-paper/95 backdrop-blur-md border border-divider shadow-2xl p-4 rounded-lg animate-in fade-in zoom-in-95 duration-200">
                  {/* Search Header */}
                  <div className="flex items-center justify-between mb-3 pb-2 border-b border-divider">
                    <span className="text-xs font-bold uppercase tracking-wider text-gray-700 font-sans">
                      Search Headlines & News
                    </span>
                    <button
                      onClick={() => {
                        setIsSearchOpen(false);
                        setSearchQuery("");
                      }}
                      className="p-1 text-gray-500 hover:text-red-700 transition-colors rounded hover:bg-black/5"
                      aria-label="Close Search Panel"
                    >
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </div>

                  {/* Input Field */}
                  <div className="flex items-center border border-divider bg-white px-3 py-2 rounded mb-3 shadow-inner">
                    <svg className="w-4 h-4 text-gray-400 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                    <input
                      type="text"
                      placeholder="Type keywords to search news..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full text-xs outline-none bg-transparent text-ink placeholder:text-gray-400 font-sans"
                      autoFocus
                    />
                    {searchQuery && (
                      <button
                        type="button"
                        onClick={() => setSearchQuery("")}
                        className="text-gray-400 hover:text-ink ml-1"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                      </button>
                    )}
                  </div>

                  {/* Search Results List */}
                  <div className="max-h-72 overflow-y-auto divide-y divide-divider border-t border-divider">
                    {searchQuery.trim() !== "" ? (
                      searchResults.length > 0 ? (
                        searchResults.map((article) => (
                          <Link
                            key={`${article.category}-${article.slug}`}
                            href={`/${article.category}/${article.slug}`}
                            onClick={() => {
                              setIsSearchOpen(false);
                              setSearchQuery("");
                            }}
                            className="group p-3 flex flex-col gap-1 hover:bg-black/5 transition-colors block text-left"
                          >
                            <div className="flex items-center justify-between text-[10px]">
                              <span className="bg-ink text-paper px-1.5 py-0.5 font-bold uppercase tracking-widest rounded-xs font-sans">
                                {article.category}
                              </span>
                              {article.date && (
                                <span className="text-gray-500 font-sans">{article.date}</span>
                              )}
                            </div>
                            <h5 className="text-xs font-serif font-bold text-ink group-hover:text-red-700 transition-colors leading-snug">
                              {article.title}
                            </h5>
                          </Link>
                        ))
                      ) : (
                        <div className="p-4 text-center text-xs text-gray-500 font-sans">
                          No news articles found for &quot;{searchQuery}&quot;.
                        </div>
                      )
                    ) : (
                      <div className="p-3 text-xs text-gray-500 font-sans">
                        <p className="font-semibold text-ink mb-2">Popular Topics:</p>
                        <div className="flex flex-wrap gap-1.5">
                          {["Technology", "Markets", "Climate", "World", "US"].map((topic) => (
                            <button
                              key={topic}
                              type="button"
                              onClick={() => setSearchQuery(topic)}
                              className="bg-black/5 hover:bg-black/10 px-2.5 py-1 rounded-full text-[11px] text-ink font-medium transition-colors"
                            >
                              {topic}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-1.5 rounded hover:bg-black/5 transition-colors focus:outline-none"
              aria-label="Open Mobile Menu"
            >
              <svg className="w-6 h-6 text-ink" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                {isMenuOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* SECTION 2: Masterhead Branding Section */}
      {/* ------------------------------------------------------------- */}
      <div className="py-7 px-4 md:px-8 text-center bg-paper">
        <div className="container mx-auto flex flex-col items-center justify-center">
          <Link href="/" className="group inline-flex flex-col items-center">
            {/* Delta Emblem + DOMAIN NAME Logo Title */}
            <div className="flex items-center gap-3 mb-1">
              <svg viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6 md:w-8 md:h-8 text-ink group-hover:scale-110 group-hover:-rotate-3 transition-transform duration-500 ease-out">
                <path d="M12 3L2 21h20L12 3zm0 4.5l6.5 11.5h-13L12 7.5z" />
              </svg>
              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black font-serif tracking-tight text-ink uppercase group-hover:text-amber-950 transition-colors duration-300">
                DOMAIN NAME
              </h1>
            </div>

            {/* Single Subtle Line separating title & single-line tagline */}
            <div className="w-full max-w-xl border-t border-ink/40 pt-1.5 mt-1 px-2">
              <p className="text-[10px] sm:text-xs tracking-[0.25em] uppercase font-bold text-gray-700 font-sans text-center whitespace-nowrap">
                THE STANDARD OF INDEPENDENT JOURNALISM • EST. 1924
              </p>
            </div>
          </Link>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* SECTION 3: Smooth Serif Navigation Bar (Single Soft Top Line) */}
      {/* ------------------------------------------------------------- */}
      <nav className="hidden md:block w-full bg-paper/95 backdrop-blur-sm py-3 px-4 border-t border-ink/30 sticky top-0 z-40 transition-all">
        <div className="container mx-auto flex items-center justify-center gap-6 md:gap-10 text-sm md:text-base font-serif font-bold uppercase tracking-wider">
          {categories.map((cat) => {
            const isActive = pathname === cat.href;
            return (
              <Link
                key={cat.name}
                href={cat.href}
                className={`py-1 transition-all duration-300 relative group ${
                  isActive
                    ? "font-black text-ink border-b-2 border-ink pb-0.5"
                    : "text-ink/80 hover:text-ink"
                }`}
              >
                {cat.name}
                {!isActive && (
                  <span className="absolute bottom-0 left-0 w-0 h-[2px] bg-ink transition-all duration-300 group-hover:w-full"></span>
                )}
              </Link>
            );
          })}
        </div>
      </nav>

      {/* Mobile Drawer Overlay */}
      {isMenuOpen && (
        <div className="md:hidden fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex justify-end animate-fade-in">
          <div className="w-4/5 max-w-sm bg-paper h-full shadow-2xl flex flex-col p-6 overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-divider mb-6">
              <div className="flex items-center gap-2">
                <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 text-ink">
                  <path d="M12 3L2 21h20L12 3zm0 4.5l6.5 11.5h-13L12 7.5z" />
                </svg>
                <span className="font-serif font-black text-xl">DOMAIN NAME</span>
              </div>
              <button
                onClick={() => setIsMenuOpen(false)}
                className="p-1 rounded hover:bg-black/10 transition-colors"
                aria-label="Close Menu"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <div className="flex flex-col gap-3 mb-8">
              <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1 font-sans">
                Categories
              </p>
              {categories.map((cat) => {
                const isActive = pathname === cat.href;
                return (
                  <Link
                    key={cat.name}
                    href={cat.href}
                    onClick={() => setIsMenuOpen(false)}
                    className={`text-base font-serif font-bold transition-colors py-1.5 px-3 rounded ${
                      isActive ? "bg-ink text-paper" : "text-ink hover:bg-black/5"
                    }`}
                  >
                    {cat.name}
                  </Link>
                );
              })}
            </div>

            <div className="mt-auto border-t border-divider pt-4 text-xs text-gray-600 font-sans">
              <p className="font-semibold text-ink mb-1">{currentDate}</p>
              <p className="text-[11px]">New York 74°F</p>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
