import { getArticleBySlug } from "@/lib/api";
import { notFound } from "next/navigation";
import Image from "next/image";
import Link from "next/link";

interface DetailPageProps {
  params: Promise<{
    category: string;
    slug: string;
  }>;
}

export default async function DetailPage({ params }: DetailPageProps) {
  const { category, slug } = await params;
  const article = await getArticleBySlug(category, slug);

  if (!article) {
    notFound();
  }

  return (
    <article className="animate-fade-in bg-white">
      {/* Header Section */}
      <header className="container mx-auto px-4 md:px-8 pt-12 pb-8 max-w-4xl text-center">
        <Link 
          href={`/${article.category}`}
          className="inline-block text-brand-red font-bold uppercase tracking-widest text-sm mb-6 hover:underline"
        >
          {article.category}
        </Link>
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-black font-serif text-brand-dark leading-tight mb-6">
          {article.title}
        </h1>
        <p className="text-xl text-gray-600 font-serif leading-relaxed mb-8 max-w-3xl mx-auto">
          {article.shortdescription}
        </p>
        
        {article.author && (
          <div className="flex items-center justify-center space-x-4 border-t border-b border-gray-100 py-4 max-w-xl mx-auto">
            {article.author.image ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img 
                src={article.author.image} 
                alt={article.author.name}
                className="w-12 h-12 rounded-full object-cover"
              />
            ) : (
              <div className="w-12 h-12 rounded-full bg-brand-blue flex items-center justify-center text-white font-bold text-xl">
                {article.author.name.charAt(0)}
              </div>
            )}
            <div className="text-left">
              <p className="font-bold text-brand-dark">{article.author.name}</p>
              {article.author.role && (
                <p className="text-sm text-gray-500">{article.author.role}</p>
              )}
            </div>
            <div className="pl-4 ml-4 border-l border-gray-200 text-sm text-gray-500 font-medium">
              {article.date}
            </div>
          </div>
        )}
      </header>

      {/* Featured Image */}
      <div className="container mx-auto px-4 md:px-8 max-w-6xl mb-16">
        <div className="aspect-video w-full relative overflow-hidden rounded-xl shadow-lg">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img 
            src={article.image}
            alt={article.title}
            className="w-full h-full object-cover"
          />
        </div>
      </div>

      {/* Article Content */}
      <div className="container mx-auto px-4 md:px-8 max-w-3xl pb-20">
        <div className="prose prose-lg md:prose-xl prose-brand max-w-none">
          {article.description?.map((section, index) => (
            <div key={index} className="mb-10">
              {section.subtitle && (
                <h2 className="text-2xl md:text-3xl font-bold font-serif text-brand-dark mb-4 mt-8">
                  {section.subtitle}
                </h2>
              )}
              {/* Splitting text by newlines to render multiple paragraphs if they exist */}
              {section.text.split('\n\n').map((paragraph, pIndex) => (
                <p key={pIndex} className="text-gray-800 leading-relaxed mb-6 font-serif">
                  {paragraph}
                </p>
              ))}
            </div>
          ))}
        </div>
        
        {/* Author Bio Section */}
        {article.author && article.author.bio && (
          <div className="mt-16 pt-8 border-t-2 border-brand-red/20 bg-brand-gray p-8 rounded-xl">
            <h3 className="text-xl font-bold text-brand-dark mb-2">About the Author</h3>
            <p className="text-gray-700 italic">
              {article.author.bio}
            </p>
          </div>
        )}
      </div>
    </article>
  );
}
