import Link from "next/link";
import { getArticlesByCategory } from "@/lib/api";
import { notFound } from "next/navigation";

interface CategoryPageProps {
  params: Promise<{
    category: string;
  }>;
}

export default async function CategoryPage({ params }: CategoryPageProps) {
  const { category } = await params;
  const categoryArticles = await getArticlesByCategory(category);

  if (!categoryArticles || categoryArticles.length === 0) {
    notFound();
  }

  // Articles for this category strictly
  const categoryTitle = category.toUpperCase();
  const leadArticle = categoryArticles[0];
  const bulletinArticles = categoryArticles.slice(1, 6); // 5 bulletin stories (01, 02, 03, 04, 05)
  const spotlightArticle = categoryArticles[5] || categoryArticles[0];
  const gridArticles = categoryArticles;

  return (
    <main className="w-full bg-paper text-ink pb-20 animate-fade-in">
      <div className="container mx-auto px-4 lg:px-6 py-12 space-y-16">
        {/* ========================================================================= */}
        {/* SECTION 1: Lead Hero & Top Bulletins (Borderless & Category Specific) */}
        {/* ========================================================================= */}
        <section className="space-y-6">
          <div className="flex items-center justify-between pb-2 border-b border-divider/30">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-widest text-red-700 font-sans">
                • {categoryTitle}
              </span>
              <h2 className="text-sm font-bold uppercase tracking-widest font-sans text-ink">
                {categoryTitle} HEADLINES & SPECIAL COVERAGE
              </h2>
            </div>
            <span className="text-xs font-sans text-gray-700 font-bold uppercase tracking-wider">
              LIVE {categoryTitle} WIRE REPORTS
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
            {/* Left: Main Lead Hero Card (7 Cols) */}
            {leadArticle && (
              <div className="lg:col-span-7 group relative rounded-xl overflow-hidden shadow-md bg-ink min-h-[440px] flex flex-col justify-end">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={leadArticle.image}
                  alt={leadArticle.title}
                  className="absolute inset-0 w-full h-full object-cover opacity-80 group-hover:scale-105 group-hover:opacity-90 transition-all duration-700"
                />
                {/* Dark Gradient Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/75 to-transparent"></div>

                {/* Hero Content */}
                <div className="relative z-10 p-6 md:p-8 flex flex-col justify-end h-full text-paper space-y-4">
                  <div className="flex items-center gap-3 text-xs">
                    <span className="bg-red-700 text-white font-extrabold uppercase px-2.5 py-0.5 text-[10px] tracking-widest rounded-xs font-sans">
                      LEAD STORY
                    </span>
                    <span className="text-paper/80 font-sans">{leadArticle.date}</span>
                  </div>

                  <Link href={`/${leadArticle.category}/${leadArticle.slug}`}>
                    <h3 className="text-2xl sm:text-3xl md:text-4xl font-serif font-black leading-tight text-paper group-hover:text-highlight-peach transition-colors">
                      {leadArticle.title}
                    </h3>
                  </Link>

                  <p className="text-xs sm:text-sm text-paper/80 font-sans line-clamp-2 leading-relaxed">
                    {leadArticle.shortdescription}
                  </p>

                  <div className="pt-2 flex items-center justify-between border-t border-paper/20 text-xs font-sans">
                    {leadArticle.author && (
                      <div className="flex items-center gap-2">
                        {leadArticle.author.image && (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img
                            src={leadArticle.author.image}
                            alt={leadArticle.author.name}
                            className="w-6 h-6 rounded-full object-cover grayscale"
                          />
                        )}
                        <span className="font-semibold text-paper/90">
                          {leadArticle.author.name}
                        </span>
                      </div>
                    )}
                    <Link
                      href={`/${leadArticle.category}/${leadArticle.slug}`}
                      className="font-bold text-highlight-peach hover:underline inline-flex items-center gap-1 text-xs"
                    >
                      Read Full Coverage &rarr;
                    </Link>
                  </div>
                </div>
              </div>
            )}

            {/* Right: Top Bulletins List (5 Cols - 5 CATEGORY SPECIFIC STORIES) */}
            <div className="lg:col-span-5 flex flex-col justify-start space-y-3 p-2">
              <h4 className="text-xs font-extrabold uppercase tracking-widest text-ink font-sans pb-1.5 border-b border-gray-300">
                Top Category Bulletins
              </h4>

              <div className="divide-y divide-gray-200/80 space-y-2">
                {bulletinArticles.map((art, idx) => (
                  <Link
                    key={`${art.category}-${art.slug}-${idx}`}
                    href={`/${art.category}/${art.slug}`}
                    className="group pt-2.5 first:pt-0 flex items-start gap-3.5 block"
                  >
                    <span className="font-serif font-black text-xl text-gray-400 group-hover:text-red-700 transition-colors flex-shrink-0 mt-0.5">
                      0{idx + 1}
                    </span>
                    <div className="space-y-0.5 flex-1">
                      <span className="text-[10px] uppercase font-bold tracking-widest text-gray-500 font-sans">
                        {art.date}
                      </span>
                      <h5 className="text-xs sm:text-sm font-serif font-bold text-ink leading-snug group-hover:text-red-700 transition-colors line-clamp-1">
                        {art.title}
                      </h5>
                      <p className="text-[11px] text-gray-600 font-sans line-clamp-1 leading-normal">
                        {art.shortdescription}
                      </p>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* ========================================================================= */}
        {/* SECTION 2: Modern Borderless Editorial Showcase */}
        {/* ========================================================================= */}
        {spotlightArticle && (
          <section>
            {/* Super Sleek Borderless Parchment Showcase Card */}
            <div className="bg-[#EBE4D5] rounded-3xl p-6 sm:p-8 md:p-12 shadow-sm relative overflow-hidden transition-all duration-500 hover:shadow-xl">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
                {/* Left: Modern Full-Bleed Image Frame (5 Cols) */}
                <div className="lg:col-span-5 relative aspect-4/3 rounded-2xl overflow-hidden shadow-md group">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={spotlightArticle.image}
                    alt={spotlightArticle.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute top-4 left-4 bg-ink text-paper text-[10px] font-bold uppercase px-3 py-1 rounded-full tracking-widest font-sans shadow-md">
                    FEATURED STORY
                  </div>
                </div>

                {/* Right: Modern Borderless Typography Layout (7 Cols) */}
                <div className="lg:col-span-7 space-y-5">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-red-700 animate-pulse"></span>
                    <span className="text-xs font-bold font-sans uppercase tracking-[0.2em] text-gray-700">
                      {spotlightArticle.date}
                    </span>
                  </div>

                  <Link href={`/${spotlightArticle.category}/${spotlightArticle.slug}`}>
                    <h3 className="text-2xl sm:text-3xl lg:text-4xl font-serif font-black text-ink hover:text-red-700 transition-colors leading-[1.15]">
                      {spotlightArticle.title}
                    </h3>
                  </Link>

                  <p className="text-sm font-sans text-gray-700 leading-relaxed line-clamp-3 font-normal">
                    {spotlightArticle.shortdescription}
                  </p>

                  <div className="pt-2 flex flex-wrap items-center justify-between gap-4">
                    {spotlightArticle.author && (
                      <div className="flex items-center gap-3 bg-white/70 backdrop-blur-xs px-3.5 py-1.5 rounded-full shadow-xs">
                        {spotlightArticle.author.image && (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img
                            src={spotlightArticle.author.image}
                            alt={spotlightArticle.author.name}
                            className="w-7 h-7 rounded-full object-cover grayscale"
                          />
                        )}
                        <div>
                          <p className="text-xs font-bold font-sans text-ink leading-none">
                            {spotlightArticle.author.name}
                          </p>
                          <p className="text-[9px] text-gray-500 font-sans uppercase tracking-wider mt-0.5">
                            {spotlightArticle.author.role || "Senior Correspondent"}
                          </p>
                        </div>
                      </div>
                    )}

                    <Link
                      href={`/${spotlightArticle.category}/${spotlightArticle.slug}`}
                      className="inline-flex items-center gap-2 bg-ink text-paper hover:bg-red-700 text-xs font-bold uppercase tracking-widest px-6 py-3 rounded-full transition-all duration-300 font-sans shadow-md hover:scale-105"
                    >
                      <span>Read Story</span>
                      <span>&rarr;</span>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* ========================================================================= */}
        {/* SECTION 3: Modern Horizontal Editorial Timeline Strip (VARIETY DESIGN) */}
        {/* ========================================================================= */}
        <section className="space-y-8 pt-6">
          {/* Header */}
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-red-700 animate-pulse"></span>
            <h2 className="text-xs font-bold uppercase tracking-[0.25em] font-sans text-ink">
              {categoryTitle} CHRONOLOGICAL WIRE STREAM
            </h2>
          </div>

          {/* Staggered Horizontal Editorial Wire List */}
          <div className="space-y-4">
            {gridArticles.map((article, idx) => (
              <Link
                key={`wire-strip-${article.category}-${article.slug}-${idx}`}
                href={`/${article.category}/${article.slug}`}
                className="group flex flex-col md:flex-row items-start md:items-center justify-between gap-6 p-4 md:p-5 rounded-2xl bg-paper hover:bg-[#EBE4D5]/70 transition-all duration-300 hover:shadow-lg hover:-translate-y-0.5"
              >
                {/* Left: Index & Thumbnail Preview */}
                <div className="flex items-center gap-4 sm:gap-6 flex-shrink-0 w-full md:w-auto">
                  <span className="font-serif font-black text-2xl md:text-3xl text-gray-400 group-hover:text-red-700 transition-colors duration-300">
                    0{idx + 1}
                  </span>
                  <div className="relative w-28 sm:w-36 aspect-16/10 rounded-xl overflow-hidden shadow-xs flex-shrink-0 bg-gray-200">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={article.image}
                      alt={article.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out"
                    />
                  </div>
                </div>

                {/* Middle: Article Meta, Title & Description */}
                <div className="flex-1 space-y-1">
                  <span className="text-[10px] font-sans font-bold uppercase tracking-widest text-gray-500">
                    {article.date}
                  </span>
                  <h4 className="text-base sm:text-lg font-serif font-bold text-ink leading-snug group-hover:text-red-700 transition-colors duration-300 line-clamp-2">
                    {article.title}
                  </h4>
                  <p className="text-xs text-gray-700 font-sans line-clamp-1 leading-relaxed hidden sm:block">
                    {article.shortdescription}
                  </p>
                </div>

                {/* Right: Author & Action Link */}
                <div className="flex items-center justify-between md:flex-col md:items-end gap-2 flex-shrink-0 w-full md:w-auto pt-2 md:pt-0 border-t border-divider/30 md:border-t-0 text-xs font-sans">
                  {article.author ? (
                    <span className="text-gray-600 font-medium">
                      By {article.author.name}
                    </span>
                  ) : (
                    <span className="text-gray-500">Wire Dispatch</span>
                  )}
                  <span className="font-bold text-red-700 group-hover:translate-x-1.5 transition-transform duration-300 inline-flex items-center gap-1">
                    Read Story &rarr;
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}
